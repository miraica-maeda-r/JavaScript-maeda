{\rtf1\ansi\ansicpg932\cocoartf2638
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\fnil\fcharset128 HiraginoSans-W3;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 const text = document.querySelector('#colorText');\
const color = document.querySelector('#colorPicker');\
// 
\f1 \'83\'4a\'83\'89\'81\'5b\'83\'73\'83\'62\'83\'4a\'81\'5b\'82\'f0\'91\'80\'8d\'ec\'82\'b5\'82\'bd\'82\'c6\'82\'ab\'82\'cc\'88\'ea\'98\'41\'82\'cc\'93\'ae\'8d\'ec
\f0 \
const color\'dfg = () => \{\
// 
\f1 \'91\'49\'91\'f0\'82\'b5\'82\'bd\'90\'46\'82\'f0\'94\'77\'8c\'69\'90\'46\'82\'c9\'90\'dd\'92\'e8
\f0 \
document.body.style.backgroundColor = color.value;\
// 
\f1 \'83\'4a\'83\'89\'81\'5b\'83\'52\'81\'5b\'83\'68\'82\'f0\'95\'5c\'8e\'a6
\f0 \
if (color.value === '#ffffff') \{\
text.textContent = '
\f1 \'83\'4a\'83\'89\'81\'5b\'83\'52\'81\'5b\'83\'68
\f0 : $\{color.value) (white);\
\} else if (color.value === '#000000') (\
text.textContent = 
\f1 \'83\'4a\'83\'89\'81\'5b\'83\'52\'81\'5b\'83\'68
\f0 : $\{color.value) (black)'; \} else \{\
text.textContent = 
\f1 \'83\'4a\'83\'89\'81\'5b\'83\'52\'81\'5b\'83\'68
\f0 : $\{color.value\}';\
\}\
// 
\f1 \'83\'4a\'83\'89\'81\'5b\'83\'73\'83\'62\'83\'4a\'81\'5b\'82\'aa\'95\'cf\'8d\'58\'82\'b3\'82\'ea\'82\'bd\'82\'e7
\f0  colorBg 
\f1 \'82\'f0\'94\'ad\'93\'ae\'82\'b3\'82\'b9\'82\'e9
\f0 \
color.addEventListener('input', colorBg);}